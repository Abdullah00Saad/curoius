
         function openNav() {
            document.getElementById("mySidenav").style.width = "220px";
            document.getElementById("MyLogo").style.visibility = "hidden";
            MyLogo.classList.toggle("m-fadeOut");



         }

         function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("MyLogo").style.visibility = "visible";
            MyLogo.classList.toggle("m-fadeIn");
         }





         